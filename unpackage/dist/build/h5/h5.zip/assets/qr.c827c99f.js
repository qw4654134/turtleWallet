const s="/assets/doller-transfer.aad16c1b.png",a="/assets/qr.5444bc3d.png";export{s as _,a};

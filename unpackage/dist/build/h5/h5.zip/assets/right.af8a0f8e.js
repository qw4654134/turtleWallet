const s="/assets/right.72e5c5c8.png";export{s as _};

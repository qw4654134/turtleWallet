const s="/assets/close.95d9dd5b.png";export{s as _};

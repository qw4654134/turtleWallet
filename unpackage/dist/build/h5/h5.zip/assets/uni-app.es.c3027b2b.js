import{z as r}from"./index.0a4c0685.js";function n(n,o){return r(n)?o:n}export{n as r};

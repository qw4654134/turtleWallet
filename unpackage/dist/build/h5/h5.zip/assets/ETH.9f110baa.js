const s="/assets/ETH.51d323ea.png";export{s as _};

const s="/assets/send.793f6f1f.png",e="/assets/receive.fc795ed4.png";export{s as _,e as a};

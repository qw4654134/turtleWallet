import{z as r}from"./index.3b969e63.js";function e(e,n){return r(e)?n:e}export{e as r};

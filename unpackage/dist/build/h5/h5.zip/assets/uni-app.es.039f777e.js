import{z as r}from"./index.e3856387.js";function e(e,n){return r(e)?n:e}export{e as r};

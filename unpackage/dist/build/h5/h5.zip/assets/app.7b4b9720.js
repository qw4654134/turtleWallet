import{a,r as t}from"./index.3b969e63.js";const r={checkAppInit:function(){return!!a().globalData.global_is_app_data_init||(t({url:"/pages/start/start-up"}),!1)}};export{r as A};

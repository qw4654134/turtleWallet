const s="/assets/wallet.8f232077.png";export{s as _};

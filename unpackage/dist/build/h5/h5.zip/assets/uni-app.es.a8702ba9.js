import{z as r}from"./index.00515032.js";function n(n,o){return r(n)?o:n}export{n as r};
